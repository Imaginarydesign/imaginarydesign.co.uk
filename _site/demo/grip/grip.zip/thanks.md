Thanks for downloading the theme! I hope you enjoy it!

Please let me know if you have any issues or questions.

Thanks again! — Adam